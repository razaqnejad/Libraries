#include "Arduino.h"
class R7segment{
  int pin[8];  //A,B,C,D,E,F,G,DP
  bool COM=0;
public:
  #define ANOD 1
  #define CATH 0
  #define ON !COM
  #define OFF COM
  R7segment(bool,int,int,int,int,int,int,int,int);
  R7segment(bool,int,int,int,int,int,int,int);
  void Display(int);
  void DP(bool);
  void test();
private:
  void turnON();
  void turnOFF();
};
