#include "R7segment.h"

R7segment :: R7segment(bool COM,int A,int B,int C,int D,int E,int F,int G,int DP){
  this->COM=COM;
  this->pin[0]=A;
  this->pin[1]=B;
  this->pin[2]=C;
  this->pin[3]=D;
  this->pin[4]=E;
  this->pin[5]=F;
  this->pin[6]=G;
  this->pin[7]=DP;
  for(int i=0 ; i<8 ; i++){
    pinMode(pin[i],OUTPUT);
    digitalWrite(pin[i],COM);
  }
}
R7segment :: R7segment(bool COM,int A,int B,int C,int D,int E,int F,int G){
  this->COM=COM;
  this->pin[0]=A;
  this->pin[1]=B;
  this->pin[2]=C;
  this->pin[3]=D;
  this->pin[4]=E;
  this->pin[5]=F;
  this->pin[6]=G;
  for(int i=0 ; i<7 ; i++){
    pinMode(pin[i],OUTPUT);
    digitalWrite(pin[i],COM);
  }
}
void R7segment :: test(){
  for(int i=0 ; i<8 ; i++){
    digitalWrite(pin[i],!COM);
  }
}
void R7segment :: turnON(){
  for(int i=0 ; i<7 ; i++){
    digitalWrite(pin[i],!COM);
  }
}
void R7segment :: turnOFF(){
  for(int i=0 ; i<7 ; i++){
    digitalWrite(pin[i],COM);
  }
}
void R7segment :: Display(int num){
  switch(num){
    case 0:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],!COM);
      digitalWrite(pin[4],!COM);
      digitalWrite(pin[5],!COM);
      digitalWrite(pin[6],COM);
      break;
    case 1:
      digitalWrite(pin[0],COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],COM);
      digitalWrite(pin[4],COM);
      digitalWrite(pin[5],COM);
      digitalWrite(pin[6],COM);
      break;
    case 2:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],COM);
      digitalWrite(pin[3],!COM);
      digitalWrite(pin[4],!COM);
      digitalWrite(pin[5],COM);
      digitalWrite(pin[6],!COM);
      break;
    case 3:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],!COM);
      digitalWrite(pin[4],COM);
      digitalWrite(pin[5],COM);
      digitalWrite(pin[6],!COM);
      break;
    case 4:
      digitalWrite(pin[0],COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],COM);
      digitalWrite(pin[4],COM);
      digitalWrite(pin[5],!COM);
      digitalWrite(pin[6],!COM);
      break;
    case 5:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],!COM);
      digitalWrite(pin[4],COM);
      digitalWrite(pin[5],!COM);
      digitalWrite(pin[6],!COM);
      break;
    case 6:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],!COM);
      digitalWrite(pin[4],!COM);
      digitalWrite(pin[5],!COM);
      digitalWrite(pin[6],!COM);
      break;
    case 7:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],COM);
      digitalWrite(pin[4],COM);
      digitalWrite(pin[5],COM);
      digitalWrite(pin[6],COM);
      break;
    case 8:
      turnON();
      break;
    case 9:
      digitalWrite(pin[0],!COM);
      digitalWrite(pin[1],!COM);
      digitalWrite(pin[2],!COM);
      digitalWrite(pin[3],!COM);
      digitalWrite(pin[4],COM);
      digitalWrite(pin[5],!COM);
      digitalWrite(pin[6],!COM);
      break;
    default:
      turnOFF();
      break;
  }
}
void R7segment :: DP(bool state){
  pinMode(this->pin[7],state);
}