#include "RPushButton.h"
RPushButton :: RPushButton(int pin,int state){
    this->pin = pin;
    pinMode(pin,state);
}
int RPushButton :: count(){
    int value = digitalRead(pin);
    if (value!=state && value==0)
        counter++;
    state = value;
    return counter;
}
void RPushButton :: reset(){
    this->counter=0;
}