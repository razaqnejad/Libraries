#include "Arduino.h"
class RPushButton{
    int pin, counter=0;
    bool state=1;
public:
    RPushButton(int,int=INPUT_PULLUP);
    int count();
    void reset();
};