#include "RSRF.h"
RSRF :: RSRF(int trig,int echo){
    this->trig = trig;
    this->echo = echo;
    pinMode(trig,OUTPUT);
    pinMode(echo,INPUT);
}
unsigned long RSRF :: readSRF(){
    digitalWrite(trig, 0);
    delayMicroseconds(2);
    digitalWrite(trig, 1);
    delayMicroseconds(10);
    digitalWrite(trig, 0);
    return pulseIn(echo,1,timeout);
}
unsigned int RSRF :: read_cm(){
    return readSRF()/58;
}
unsigned int RSRF :: read_mm(){
    return (readSRF()*10)/58;
}
unsigned int RSRF :: read_inch(){
    return (readSRF()*100)/1455;
}
void RSRF :: timeOut(int timeout){
    this->timeout=timeout;
}