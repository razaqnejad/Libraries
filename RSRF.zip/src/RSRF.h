#include "Arduino.h"
class RSRF{
    int trig,echo,timeout=12000;
public:
    RSRF(int trig,int echo);
    unsigned int read_cm();
    unsigned int read_mm();
    unsigned int read_inch();
    void timeOut(int);
private:
    unsigned long readSRF();
};